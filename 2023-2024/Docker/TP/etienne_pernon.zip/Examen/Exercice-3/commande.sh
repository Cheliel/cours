
#3.4
kubectl delete pod my-caddy

# 3.5 

