

#1.2
docker build -t my-mysql --build-arg =Etienne .

